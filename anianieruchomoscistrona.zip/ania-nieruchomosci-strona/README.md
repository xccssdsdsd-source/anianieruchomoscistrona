# Strona ania.nieruchomosci — folder roboczy

Zebrane dane z profilu Instagram + gotowy szkielet strony (placeholdery do uzupełnienia).

## Struktura

- `dane-zrodlowe/profil-instagram.md` — wszystko wyciągnięte z profilu IG (bio, kontakt, statystyki, branding firmy).
- `dane-zrodlowe/przyklady-tresci.md` — 10 prawdziwych opisów ofert z jej postów (wzór tonu i formatu na treści do strony).
- `strona/` — szkielet HTML/CSS strony (5 podstron), wszystkie dane do uzupełnienia oznaczone `[PLACEHOLDER]`.

## Braki do uzupełnienia przed publikacją

1. Zdjęcia — profilowe, biuro, oferty (IG blokuje pobieranie automatyczne, zrzuty trzeba zapisać ręcznie albo poprosić o pliki od klientki).
2. Który numer telefonu ma być głównym na stronie: 729 960 454 czy 600 107 440 (oba widoczne w postach, użyte naprzemiennie).
3. Adres e-mail — nie znaleziony na profilu IG.
4. Pełne imię i nazwisko — na profilu widnieje tylko pseudonim „Ania" (potwierdzony w komentarzu pod jednym z postów). Nazwisko nieznane.
5. Realne oferty nieruchomości do wstawienia zamiast przykładowych kart.
6. Faktyczna firma / miejsce pracy Ani i adres biura — do ustalenia u klienta. W kilku postach pojawia się
   „Biuro Nieruchomości Pierwsze Piętro" (Al. Gen. Okulickiego 12, Rzeszów, 1pietro.net), ale klient
   potwierdził, że Ania tam NIE pracuje — nie wpisywać tej nazwy ani tego adresu na stronie.
